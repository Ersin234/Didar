const express = require('express');
const app = express();

const PORT = process.env.PORT || 3000;

// JSON денелерін өңдеуге арналған middleware
app.use(express.json());

// Тапсырмалар массиві
let todos = [
  { id: 1, title: 'Express-ті үйрену', done: false }
];

// Барлық тапсырмаларды алу маршруты
app.get('/api/todos', (req, res) => {
  res.status(200).json(todos);
});

// Query-параметрі бар сәлемдесу маршруты
app.get('/api/hello', (req, res) => {
  const { name } = req.query;

  if (name) {
    return res.status(200).json({ message: `Сәлем, ${name}!` });
  }

  return res.status(200).json({ message: 'әлем' });
});

// Жол параметрі (route parameter) бар сәлемдесу маршруты
app.get('/api/hello/:name', (req, res) => {
  const { name } = req.params;
  res.status(200).json({ message: `Сәлем, ${name}!` });
});

// Сервер күйін тексеретін маршрут
app.get('/api/status', (req, res) => {
  res.status(200).json({
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Серверді іске қосу
app.listen(PORT, () => {
  console.log(`Сервер http://localhost:${PORT} портында іске қосылды`);
});