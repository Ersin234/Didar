export default function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <h2 className="logo">Bilim орталығы</h2>
        <nav>
          <a href="#home">Басты бет</a>
          <a href="#about">Біз туралы</a>
          <a href="#services">Курстар</a>
          <a href="#contact">Байланыс</a>
        </nav>
      </div>
    </header>
  )
}