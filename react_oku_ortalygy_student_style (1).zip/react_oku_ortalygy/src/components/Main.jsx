export default function Main() {
  return (
    <section className="main-section" id="home">
      <div className="container main-content">
        <div>
          <p className="small-title">ҚОШ КЕЛДІҢІЗ!</p>
          <h1>Білім ал —<br />болашағыңды құр</h1>
          <p className="main-text">
            Bilim оқу орталығы оқушыларға жаңа білім алып, өз қабілеттерін
            дамытуға көмектеседі. Бізбен бірге оқып, алға қадам жаса!
          </p>
          <a className="main-button" href="#services">Курстарды қарау</a>
        </div>
        <div className="main-picture">
          <div className="picture-box">
            <div className="book">📚</div>
            <h3>Оқу — үлкен мүмкіндік</h3>
            <p>Жаңа білім, жаңа жетістік</p>
          </div>
        </div>
      </div>
    </section>
  )
}